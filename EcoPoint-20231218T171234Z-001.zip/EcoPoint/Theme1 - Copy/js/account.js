$('.Orders').click(function(){
    location.replace('account.html')
})  

$('.AccountDetails').click(function(){
    location.replace('accountdetails.html')
})  
$('.Address').click(function(){
    location.replace('address.html')
})  
$('.Returns').click(function(){
    location.replace('returns.html')
}) 