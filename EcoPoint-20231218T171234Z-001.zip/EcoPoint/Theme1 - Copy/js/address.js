$('.editbtnforbilling').click(function(){
    $('.bothaddress').css('display','none')
    $('.changeaddressdiv').css('display','block')

})

$('.editbtnforShipping').click(function(){
    $('.bothaddress').css('display','none')
    $('.changeaddressdiv').css('display','block')

    
})