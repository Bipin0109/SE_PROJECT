
let recycled = [{
  Name: "Wine Boxy Tee",
  Price: "899.00",
  img: ["https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A6010-1.jpg?v=1657360426&width=823",
      "https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A6015-1.jpg?v=1657360426&width=1100",
      " https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A6015-1.jpg?v=1657360426&width=1100"
  ]
},
{
  Name: "Dark Green Boxy Tee",
  Price: "899.00",
  img: ["https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A5990-1.jpg?v=1657362469&width=823",
      "https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A5999-1.jpg?v=1657362469&width=1100",
      "https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A5998-1.jpg?v=1657362469&width=1100"
  ]
},
{
  Name: "Coral Boxy Tee",
  Price: "899.00",
  img: ["https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A5942-1.jpg?v=1657360604&width=823",
      " https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A5948-1.jpg?v=1657360604&width=1100",
      "https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A5950-1.jpg?v=1657360604&width=1100"
  ]
  
},
{
  Name: "Little Mischief Boxy Tee",
  Price: "999.00",
  img: ["https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A6028-1.jpg?v=1657362872&width=823",
      "https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A6026-1.jpg?v=1657362872&width=1100",
      "https://cdn.shopify.com/s/files/1/0582/3093/1608/products/472A6035-1.jpg?v=1657362872&width=1100"

  ]
}];



